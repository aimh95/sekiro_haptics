from pathlib import Path
import concurrent.futures
import json
import re
import subprocess

root = Path(__file__).parent
src = root.parent / 'sekiro_haptics'
out = root / 'build-common'
out.mkdir(exist_ok=True)
core = re.findall(r'(?m)^    (src/[^ ]+\.cpp)', (src/'CMakeLists.txt').read_text().split('target_include_directories(sekiro_haptics PUBLIC')[0])
tests = re.findall(r'(?m)^    (test_[^ ]+\.cpp)', (src/'tests/CMakeLists.txt').read_text().split('target_include_directories(sekiro_haptics_tests PRIVATE')[0])
files = core + ['tests/' + x for x in tests]

def compile_one(name):
    obj = out / (name.replace('/', '_') + '.o')
    command = ['g++', '-std=c++20', '-O0', '-g1', '-Wall', '-Wextra', '-pthread',
               '-I'+str(src/'include'), '-I'+str(src/'tests'),
               '-DSH_FIXTURES_DIR="'+str(src/'tests/fixtures')+'"', '-c', str(src/name), '-o', str(obj)]
    result = subprocess.run(command, capture_output=True, text=True)
    if result.returncode == 0 and (not obj.exists() or obj.stat().st_size == 0):
        result = subprocess.run(command, capture_output=True, text=True)
    return name, obj, result.returncode or (1 if obj.stat().st_size == 0 else 0), result.stdout + result.stderr

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
    results = list(executor.map(compile_one, files))
(root/'build.log').write_text(''.join(name+'\n'+message for name, obj, code, message in results if message))
(root/'build_sources.json').write_text(json.dumps(files, indent=2))
failures = [name for name, obj, code, message in results if code]
if failures:
    print('COMPILE FAILED:', failures)
    raise SystemExit(1)
result = subprocess.run(['g++', '-pthread', *[str(obj) for _, obj, _, _ in results],
                         '-o', str(out/'sekiro_haptics_tests')], capture_output=True, text=True)
with (root/'build.log').open('a') as log:
    log.write(result.stdout+result.stderr)
print('COMMON BUILD:', 'PASS' if result.returncode == 0 else 'FAIL', 'translation units:', len(files))
raise SystemExit(result.returncode)
