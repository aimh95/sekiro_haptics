#!/usr/bin/env python3
"""Apply this update to the exact supplied ZIP baseline, preserving local work.

python update/apply_update.py --repo C:\\workspace\\sekiro_haptics
python update/apply_update.py --repo C:\\workspace\\sekiro_haptics --apply
Default: check only. No force mode. All files are checked before any write.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile


def normalized(data):
    return data.replace(b"\r\n",b"\n")


def digest(data):
    return hashlib.sha256(normalized(data)).hexdigest()


def atomic_write(path, data, mode=0o644):
    path.parent.mkdir(parents=True,exist_ok=True)
    fd, name = tempfile.mkstemp(prefix="feedback-update-",dir=path.parent)
    temporary = Path(name)
    try:
        with os.fdopen(fd,"wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        temporary.chmod(mode)
        os.replace(temporary,path)
    finally:
        if temporary.exists(): temporary.unlink()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo",type=Path,required=True)
    parser.add_argument("--apply",action="store_true")
    args = parser.parse_args()
    root = args.repo.resolve(strict=True)
    if not (root/"CMakeLists.txt").is_file(): raise ValueError("expected repository root containing CMakeLists.txt")
    package = Path(__file__).resolve().parent
    entries = json.loads((package/"base_manifest.json").read_text())["files"]
    pending = []
    conflicts = []
    for entry in entries:
        relative = Path(entry["path"])
        if relative.is_absolute() or ".." in relative.parts: raise ValueError("invalid manifest path")
        target = (root/relative).resolve()
        if not target.is_relative_to(root): raise ValueError("target escapes repository root")
        incoming = (package/"changed_files"/relative).read_bytes()
        if digest(incoming) != entry["updated_sha256"]: raise ValueError("update payload hash mismatch: "+str(relative))
        if target.exists() and not target.is_file():
            conflicts.append(str(relative)); continue
        old = target.read_bytes() if target.exists() else None
        actual = digest(old) if old is not None else None
        if actual == entry["updated_sha256"]: continue
        accepted = entry.get("accepted_baseline_sha256", [entry["baseline_sha256"]])
        if actual not in accepted:
            conflicts.append(str(relative)); continue
        mode = (target.stat().st_mode & 0o777) if target.exists() else 0o644
        incoming = normalized(incoming)
        if old is not None and b"\r\n" in old and b"\n" not in old.replace(b"\r\n",b""):
            incoming = incoming.replace(b"\n",b"\r\n")
        pending.append((relative,target,old,incoming,mode))
    if conflicts:
        print("Local files differ from the uploaded baseline or the previous delivered version. Nothing was changed:",file=sys.stderr)
        for path in conflicts: print("  "+path,file=sys.stderr)
        print("Review sekiro_feedback.patch and merge these files manually; do not overwrite local work.",file=sys.stderr)
        return 2
    print(f"Preflight passed: {len(pending)} files to update, {len(entries)-len(pending)} already current.")
    if not args.apply or not pending: return 0
    backup_root = root/"feedback_update_backups"
    backup_root.mkdir(exist_ok=True)
    backup = Path(tempfile.mkdtemp(prefix=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ-"),dir=backup_root))
    done = []
    try:
        for relative,target,old,incoming,mode in pending:
            current = target.read_bytes() if target.exists() else None
            if current != old: raise ValueError("file changed after preflight: "+str(relative))
            if old is not None:
                saved = backup/relative; saved.parent.mkdir(parents=True,exist_ok=True)
                shutil.copy2(target,saved)
            # Register rollback before replacement, including previously absent files.
            done.append((target,old,mode))
            atomic_write(target,incoming,mode)
        (backup/"update_manifest.json").write_text(json.dumps({"files":[str(p[0]) for p in pending],
            "created_files":[str(p[0]) for p in pending if p[2] is None]},indent=2))
    except Exception:
        for target,old,mode in reversed(done):
            if old is None:
                if target.exists(): target.unlink()
            else: atomic_write(target,old,mode)
        raise
    print(f"Updated {len(done)} files. Original files backed up at: {backup}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError,ValueError) as error:
        print(f"Update failed: {error}",file=sys.stderr)
        raise SystemExit(1)
