# 세키로 패링·방어 신호 조사와 듀얼센스 피드백 개발본

**Windows에서 빌드할 소스와 실행 도구를 구현했다.** 패링 충격·소리, 의수 10종의 R2 저항과 반동, 와이어 발사·걸림·당김·종료에 따른 L2 효과가 들어 있다.

**다음 우선순위는 실제 게임의 패링 성공과 일반 방어를 구별하는 신호 확인이다.** 이번 추가 개발로 v3 캡처의 원시 필드 후보 탐색, 패링/방어 각각의 평가, 별도 플레이 세션 검증을 구현했다. `sekiro_haptics/docs/10-deflect-signal-first.md`부터 읽는다. 출력 감각 튜닝은 그 뒤에 진행한다.

현재 실행기는 **수동 명령/시나리오**로 동작한다. **실제 세키로의 성공 패링·선택 의수·와이어 상태를 자동 탐지하는 연결은 아직 완료되지 않았다.** 게임 실행 파일과 라이브 관측 데이터 없이 성공 신호나 오프셋을 만들어 넣지 않았다. Windows 빌드와 실제 패드 출력도 이 Linux 환경에서 실행하지 못했다.

대상은 **PS5 DualSense의 USB 연결**이다. DualShock 4는 트리거 저항 조절 하드웨어가 없어 같은 기능을 제공할 수 없다. PC 지원 조건은 [Sony 안내](https://www.playstation.com/en-us/support/hardware/pair-dualsense-controller-bluetooth/)를 참고한다.

## 출력 부분을 별도로 시험하는 방법

1. ZIP을 새 폴더에 푼다. `sekiro_haptics/`에 기존 코드가 반영된 전체 소스가 있다.
2. Visual Studio C++ 빌드 도구와 Windows SDK, CMake를 설치한 Windows에서 아래를 실행한다. Python 3.10 이상을 함께 설치하면 캡처 분석기 테스트도 실행된다.

```powershell
cd <압축을 푼 폴더>\sekiro_haptics
cmake -S . -B build-feedback -A x64 -DSEKIRO_HAPTICS_BUILD_DUALSENSE_TRANSPORT=ON
cmake --build build-feedback --config Release --parallel
ctest --test-dir build-feedback -C Release --output-on-failure
$app = ".\build-feedback\apps\action_feedback\Release\sekiro_action_feedback.exe"
& $app --list-devices
```

3. 목록의 번호를 골라 실행한다. 아래 `0`, `3`은 예시다. 오디오 번호는 **DualSense의 재생 장치**를 선택한다.

```powershell
& $app --scenario .\configs\action_feedback_demo.jsonl --hardware --device 0 --audio-device 3
& $app --manual --hardware --device 0 --audio-device 3
```

스피커 없이 먼저 확인하려면 `--audio-device 3`을 생략한다. 패드를 연결하지 않고 명령 흐름을 확인하려면:

```powershell
& $app --scenario .\configs\action_feedback_demo.jsonl --dry-run --fast
```

수동 모드 키: `p` 패링, `b` 방어, `d` 피격, `n` 의수 변경, `u` 의수 사용, `j` 와이어 발사, `k` 걸림, `l` 당김, `e` 종료. Space는 전체 효과 해제, `r` 재개, `q` 종료다. 콘솔에 포커스를 두고 사용한다. 게임 입력을 대신하지 않는다.

## 기존 C:\workspace\sekiro_haptics에 적용하려면

기존 작업을 계속할 때는 `update/`의 검증형 적용 스크립트를 사용한다. 변경 대상 파일이 업로드한 ZIP 또는 직전 개발본의 확인된 내용과 같아야 적용한다. 줄바꿈 차이는 허용한다. 다른 로컬 변경이 있으면 전체 적용 전에 멈춘다.

```powershell
python .\update\apply_update.py --repo C:\workspace\sekiro_haptics
python .\update\apply_update.py --repo C:\workspace\sekiro_haptics --apply
```

적용 전에 모든 파일을 확인하고 원본 파일을 `feedback_update_backups/`에 보관한다. 이미 같은 업데이트가 적용되어 있으면 건너뛴다. 충돌이 있으면 `update/sekiro_feedback.patch`와 전체 소스를 비교해 병합한다. 기존 프로젝트 전체를 덮어쓰지 않는다.

## 검증 결과

- 공통 C++ 테스트 **528/528 통과**. GCC C++20으로 CMake의 공통 소스 목록을 직접 빌드해 실행했다.
- Python 캡처 검증 **11/11 통과**. 실제 C++ 기록기로 만든 파일의 왕복 복원과 덮어쓰기 거부 포함.
- 추가 Python 신호 분석 검증 **22/22 통과**. 패링/방어 분리, 독립 정답, 중복, 빠른 연속 발생, 상태 유지에 따른 누락, 객체/gap, 학습 자료 재사용 거부 포함. 모두 합성 자료이며 실게임 인식률이 아니다.
- 시나리오의 빠른 실행과 실제 시간 간격 실행 모두 통과. 90ms 간격의 패링 세 번이 각각 소리 명령을 생성하고, 마지막 출력은 중립 상태다.
- **미실행:** Windows/MSVC 빌드, 실제 HID/스피커/트리거 출력, 라이브 세키로 탐지. 이전 Linux 프로세스 접근 테스트는 이번에 재실행하지 않았다.

전체 로그와 합성 캡처는 `evidence/`에 있다. 합성 캡처와 시나리오는 게임에서 얻은 증거가 아니다.

## 다음으로 필요한 작업

**실제 EXE/플레이어 반응 데이터에서 패링과 일반 방어가 갈라지는 경로를 찾는 것이 먼저다.** 근거 있는 후보 영역을 신뢰성 수정이 들어간 probe로 읽고, 독립 영상으로 두 결과를 구분해 새 분석기로 평가한다. 플레이어/적 구분과 연속 성공까지 검증된 뒤 `ActionCommand`에 연결한다. 선택 의수·와이어 신호와 패드 출력 감각은 그다음이다.

라이브 캡처 전에 필요한 파일 보존·객체 교체 시 재기준화·실패와 공백 기록·분석 중복 제외는 구현했다. Windows에서 권한·종료 경로까지 확인해야 다음 캡처를 신뢰할 수 있다. 설정 형식 통일, 스캐너 교체, 기존 스케줄러 전면 정리, Bluetooth와 고해상도 햅틱은 후순위다.

상세 설명, 프로토콜 근거, 연동 인터페이스는 `sekiro_haptics/docs/09-action-feedback.md`에 있다. 기존 아키텍처 감사 보고서는 수정하지 않았다.
